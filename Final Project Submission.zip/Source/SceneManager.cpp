///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";

	// ** Declaration of point light slots**
	const int g_TotalPointLights = 5;
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// **No textures loaded into the shader yet**
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	bool bReturn = false;

	bReturn = CreateGLTexture(
		"./textures/wood.jpg",
		"desk");

	bReturn = CreateGLTexture(
		"./textures/plaster.jpg",
		"wall");

	bReturn = CreateGLTexture(
		"./textures/steel.jpg",
		"lamp_steel");

	bReturn = CreateGLTexture(
		"./textures/glass.jpg",
		"lamp_shade");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method builds the list of materials that the scene
 *  objects draw from. A material controls how a surface
 *  responds to the scene lights: the diffuse color tints the
 *  broad, evenly scattered light, the specular color controls
 *  the color of the highlight, and shininess controls how
 *  tight that highlight is. Higher shininess means a smaller,
 *  harder highlight, which is what separates polished metal
 *  from a matte wood finish.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// ** Wood material used for the desk plane. **
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.78f, 0.68f, 0.56f);
	woodMaterial.specularColor = glm::vec3(0.24f, 0.20f, 0.15f);
	woodMaterial.shininess = 16.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// ** Plaster material used for the back wall plane.**
	OBJECT_MATERIAL plasterMaterial;
	plasterMaterial.diffuseColor = glm::vec3(0.84f, 0.85f, 0.88f);
	plasterMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.06f);
	plasterMaterial.shininess = 4.0f;
	plasterMaterial.tag = "plaster";
	m_objectMaterials.push_back(plasterMaterial);
	
	// ** Stainless steel used for the lamp base, stem segments, and head
	// connector. **
	OBJECT_MATERIAL steelMaterial;
	steelMaterial.diffuseColor = glm::vec3(0.70f, 0.72f, 0.75f);
	steelMaterial.specularColor = glm::vec3(0.85f, 0.87f, 0.90f);
	steelMaterial.shininess = 48.0f;
	steelMaterial.tag = "steel";
	m_objectMaterials.push_back(steelMaterial);

	// ** Enameled glass material used for the lamp shade. **
	OBJECT_MATERIAL shadeMaterial;
	shadeMaterial.diffuseColor = glm::vec3(0.95f, 0.93f, 0.88f);
	shadeMaterial.specularColor = glm::vec3(0.35f, 0.34f, 0.32f);
	shadeMaterial.shininess = 22.0f;
	shadeMaterial.tag = "shade";
	m_objectMaterials.push_back(shadeMaterial);

	// ** Cloth material used for the books. **
	OBJECT_MATERIAL bookMaterial;
	bookMaterial.diffuseColor = glm::vec3(0.62f, 0.64f, 0.68f);
	bookMaterial.specularColor = glm::vec3(0.08f, 0.08f, 0.09f);
	bookMaterial.shininess = 6.0f;
	bookMaterial.tag = "book";
	m_objectMaterials.push_back(bookMaterial);

	// ** Card stock material used for the folder and envelope. **
	OBJECT_MATERIAL cardMaterial;
	cardMaterial.diffuseColor = glm::vec3(0.80f, 0.72f, 0.58f);
	cardMaterial.specularColor = glm::vec3(0.12f, 0.11f, 0.09f);
	cardMaterial.shininess = 8.0f;
	cardMaterial.tag = "card";
	m_objectMaterials.push_back(cardMaterial);

	// ** lacquered wood material used for the pencils. **
	OBJECT_MATERIAL pencilMaterial;
	pencilMaterial.diffuseColor = glm::vec3(0.85f, 0.72f, 0.30f);
	pencilMaterial.specularColor = glm::vec3(0.55f, 0.52f, 0.40f);
	pencilMaterial.shininess = 32.0f;
	pencilMaterial.tag = "pencil";
	m_objectMaterials.push_back(pencilMaterial);

	// ** Plastic material used for the pencil cup **
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.diffuseColor = glm::vec3(0.702f, 0.82f, 0.788f);
	plasticMaterial.specularColor = glm::vec3(0.20f, 0.25f, 0.12f);
	plasticMaterial.shininess = 10.0f;
	plasticMaterial.tag = "plastic";
	m_objectMaterials.push_back(plasticMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method configures the light sources for the scene and
 *  switches on the Phong lighting calculations in the fragment
 *  shader. 
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	// **Enable the lighting calculations in the fragment shader**
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	//** DIRECTIONAL LIGHT: cool ambient room fill **
	m_pShaderManager->setVec3Value("directionalLight.direction", glm::vec3(-0.55f, -0.80f, 0.25f));
	m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.16f, 0.17f, 0.19f));
	m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.62f, 0.66f, 0.74f));
	m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.18f, 0.19f, 0.22f));
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// **POINT LIGHT 0: yellow fill from the right side of the desk **
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(12.50f, 15.00f, 6.00f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.04f, 0.04f, 0.03f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.92f, 0.80f, 0.34f)); // Adds yellow tint to the point light
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.72f, 0.66f, 0.56f));
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// ** DESK PLANE ** 
	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(12.0f, 1.0f, 5.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1, 1, 1, 1);

	// **Sets the plane / desk to wood grain texture**
	SetShaderTexture("desk");

	// **Tiles the wood grain across the desk surface instead of
	// stretching one copy over the full 20 x 10 plane**
	SetTextureUVScale(2.0f, 1.0f);

	// **Sets the desk to a wood material for lighting purposes**
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	// ** BACK WALL PLANE ** 
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(12.0f, 1.0f, 8.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 8.0f, -5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the plane / desk to wood grain texture**
	SetShaderTexture("wall");

	// **Sets the desk to a wood material for lighting purposes**
	SetShaderMaterial("plaster");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	// ** LAMP BASE CYLINDER **
	// set the XYZ scale for the mesh
	// Makes the cylinder base a very flattened cylinder
	scaleXYZ = glm::vec3(2.5f, 0.3f, 2.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-9.0f, 0.0f, -2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the cylinder base of the lamp to steel texture**
	SetShaderTexture("lamp_steel");

	// **Sets the lamp base to a steel material for lighting purposes**
	SetShaderMaterial("steel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** LAMP STEM FIRST CYLINDER **
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, 2.5f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** Places the lower stem of the lamp directly on top of the lamp base **
	positionXYZ = glm::vec3(-9.0f, 0.3f, -2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the first stem segment of the lamp to steel texture**
	SetShaderTexture("lamp_steel");

	// **Sets the first lamp stem segment to a steel material for lighting purposes**
	SetShaderMaterial("steel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** LAMP STEM SECOND (ANGLED) CYLINDER **
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, 3.0f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 35.0f;

	// set the XYZ position for the mesh
	// ** Places the second section of the stem of the lamp 
	// directly on top of the first section of the stem **
	positionXYZ = glm::vec3(-9.0f, 2.76f, -2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the second stem segment of the lamp to steel texture**
	SetShaderTexture("lamp_steel");

	// **Sets the second lamp stem segment to a steel material for lighting purposes**
	SetShaderMaterial("steel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** LAMP STEM THIRD CYLINDER **
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, 3.0f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** Places the third section of the stem of the lamp 
	// directly on top of the second section of the stem **
	positionXYZ = glm::vec3(-10.72f, 5.177f, -2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the third stem segment of the lamp to steel texture**
	SetShaderTexture("lamp_steel");

	// **Sets the third lamp stem segment to a steel material for lighting purposes**
	SetShaderMaterial("steel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** LAMP STEM FOURTH (HORIZONTAL) CYLINDER **
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.15f, 2.25f, 0.15f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the mesh
	// ** Places the fourth section of the stem of the lamp 
	// directly on top of (and perpindicular to the third section of the stem **
	positionXYZ = glm::vec3(-10.76f, 8.08f, -2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the fourth stem segment of the lamp to steel texture**
	SetShaderTexture("lamp_steel");

	// **Sets the fourth lamp stem segment to a steel material for lighting purposes**
	SetShaderMaterial("steel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** LAMP HEAD CONNECTOR CYLINDER **
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f, 0.75f, 0.5f);

	// set the XYZ rotation for the mesh
	// ** Angles the Lamp Head Connector down towards the ground **
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 30.0f;

	// set the XYZ position for the mesh
	// ** Places the lamp head connector directly on the end of the fourth section of the stem **
	positionXYZ = glm::vec3(-8.51f, 8.08f, -2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the connector segment of the lamp to steel texture**
	SetShaderTexture("lamp_steel");

	// **Sets the first connector segment to a steel material for lighting purposes**
	SetShaderMaterial("steel");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** LAMP HEAD SHADE TAPERED CYLINDER **
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 1.5f, 2.0f);

	// set the XYZ rotation for the mesh
	// ** Angles the Lamp Shade down towards the ground **
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 30.0f;

	// set the XYZ position for the mesh
	// ** Places the lamp shade directly on the end of the connector **
	positionXYZ = glm::vec3(-7.385f, 6.131f, -2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the lamp shade to a glass texture**
	SetShaderTexture("lamp_shade");

	// **Sets the lamp shade to an enameled material for lighting purposes**
	SetShaderMaterial("shade");

	// draw the mesh with transformation values
	m_basicMeshes->DrawTaperedCylinderMesh();
	/****************************************************************/

	// ** BOOK STACK - BOTTOM BOOK (GREY-BLUE HARDCOVER) **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(4.2f, 0.55f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** Box mesh is centered on its origin, so Y is half the height **
	positionXYZ = glm::vec3(-1.0f, 0.275f, -2.4f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the bottom book to a grey-blue color**
	SetShaderColor(0.318f, 0.467f, 0.557f, 1.0f);

	// **Sets the bottom book to a matte cloth material for lighting purposes**
	SetShaderMaterial("book");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ** BOOK STACK - MIDDLE BOOK (LIGHT BLUE) **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(3.8f, 0.60f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** 0.55 (stack below) + 0.30 (half of this height) **
	positionXYZ = glm::vec3(-1.0f, 0.85f, -2.4f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the middle book to a light blue color**
	SetShaderColor(0.475f, 0.631f, 0.678f, 1.0f);

	// **Sets the middle book to a matte cloth material for lighting purposes**
	SetShaderMaterial("book");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ** BOOK STACK - TOP BOOK (DARK NAVY) **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.8f, 0.40f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** 1.15 (stack below) + 0.20 (half of this height) **
	positionXYZ = glm::vec3(-1.2f, 1.35f, -2.4f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the top book to a near-black navy**
	SetShaderColor(0.145f, 0.184f, 0.22f, 1.0f);

	// **Sets the top book to a matte cloth material for lighting purposes**
	SetShaderMaterial("book");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ** PENCIL CUP CYLINDER **
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.75f, 2.0f, 0.75f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** Places the pencil cup on top of the pile of books. **
	positionXYZ = glm::vec3(-1.0f, 1.55f, -2.4f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the pencil cup to a mint-blue color**
	SetShaderColor(0.702f, 0.82f, 0.788f, 1.0f);

	// **Sets the pencil cup to a matte plastic material for lighting purposes**
	SetShaderMaterial("plastic");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** PENCIL ONE (YELLOW, UPRIGHT) **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.06f, 2.4f, 0.06f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** Cylinder origin is its base, set inside the cup **
	positionXYZ = glm::vec3(-1.18f, 1.85f, -2.30f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the pencil to yellow**
	SetShaderColor(0.898f, 0.749f, 0.243f, 1.0f);

	// **Sets the pencil to a lacquered wood material for lighting purposes**
	SetShaderMaterial("pencil");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** PENCIL TWO (YELLOW, LEANING RIGHT) **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.06f, 2.6f, 0.06f);

	// set the XYZ rotation for the mesh
	// ** Tip tilts out while the bottom stays inside the cup **
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -7.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.90f, 1.85f, -2.55f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the pencil to yellow**
	SetShaderColor(0.878f, 0.722f, 0.204f, 1.0f);

	// **Sets the pencil to a lacquered wood material for lighting purposes**
	SetShaderMaterial("pencil");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** PENCIL THREE (GREY, LEANING BACK) **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.055f, 2.5f, 0.055f);

	// set the XYZ rotation for the mesh
	// ** X rotation tilts it toward the wall **
	XrotationDegrees = 6.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 4.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-1.05f, 1.85f, -2.22f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets this pencil to a dark grey**
	SetShaderColor(0.22f, 0.231f, 0.259f, 1.0f);

	// **Sets the pencil to a lacquered wood material for lighting purposes**
	SetShaderMaterial("pencil");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** PENCIL FOUR (GREY, LEANING LEFT) **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.055f, 2.3f, 0.055f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = -4.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 9.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-0.78f, 1.85f, -2.38f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets this pencil to a dark grey**
	SetShaderColor(0.259f, 0.267f, 0.298f, 1.0f);

	// **Sets the pencil to a lacquered wood material for lighting purposes**
	SetShaderMaterial("pencil");

	// draw the mesh with transformation values
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ** FRONT STACK - FOLDER **
	/******************************************************************/
	// set the XYZ scale for the mesh
	// ** Thin, since a folder is only card stock
	scaleXYZ = glm::vec3(3.4f, 0.02f, 2.6f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** Between the lamp at X = -9.0 and the book stack at X = -1.0,
	// pushed forward on the desk. Box origin is centered, so Y is half
	// the height **
	positionXYZ = glm::vec3(-5.0f, 0.01f, 1.60f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the folder to a light manila color**
	SetShaderColor(0.788f, 0.777f, 0.749f, 1.0f);

	// **Sets the folder to a card stock material for lighting purposes**
	SetShaderMaterial("card");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ** FRONT STACK - NOTEBOOK **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.2f, 0.30f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** 0.02 (folder) + 0.15 (half of this height) **
	positionXYZ = glm::vec3(-5.0f, 0.17f, 1.60f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the notebook to a dark forest green cover**
	SetShaderColor(0.196f, 0.298f, 0.263f, 1.0f);

	// **Sets the notebook to a matte cloth material for lighting purposes**
	SetShaderMaterial("book");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ** FRONT STACK - ENVELOPE **
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 0.06f, 1.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 2.0f; // Slightly angled diagonally
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	// ** 0.32 (folder plus notebook) + 0.03 (half of this height) **
	positionXYZ = glm::vec3(-5.0f, 0.35f, 1.65f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// **Sets the envelope to a paper tan color**
	SetShaderColor(0.773f, 0.682f, 0.522f, 1.0f);

	// **Sets the envelope to a card stock material for lighting purposes**
	SetShaderMaterial("card");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

}
